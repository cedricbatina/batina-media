// server/utils/mailer.js
import nodemailer from "nodemailer";

let transporter;

function getTransporter(config) {
  if (!transporter) {
    transporter = nodemailer.createTransport({
      host: config.smtpHost,
      port: Number(config.smtpPort || 587),
      secure: false,
      auth: {
        user: config.smtpUser,
        pass: config.smtpPass,
      },
    });
  }
  return transporter;
}

export async function sendVerificationEmail(to, token, config) {
  const baseUrl = config.mailVerificationBaseUrl || config.public.appBaseUrl;
  const verifyUrl = `${baseUrl}/api/auth/verify-email?token=${encodeURIComponent(
    token
  )}`;

  const transport = getTransporter(config);

  await transport.sendMail({
    from: config.mailFrom,
    to,
    subject: "Confirmez votre adresse e-mail",
    html: `
      <p>Bienvenue chez Batina Media,</p>
      <p>Merci de créer un compte. Pour activer votre compte, cliquez sur le lien ci-dessous :</p>
      <p><a href="${verifyUrl}">Confirmer mon adresse e-mail</a></p>
      <p>Si vous n'êtes pas à l'origine de cette demande, ignorez simplement ce message.</p>
    `,
  });
}

/**
 * Email de notification pour le formulaire de contact.
 */
export async function sendContactEmail(payload, config) {
  const transport = getTransporter(config);

  const {
    name,
    email,
    org,
    projectType,
    budget,
    timeline,
    message,
    locale,
  } = payload;

  // À qui envoyer côté admin
  const to = config.contactTo || config.mailFrom || config.smtpUser;
  if (!to) {
    console.warn("[sendContactEmail] Aucun contactTo / mailFrom / smtpUser configuré");
    return;
  }

  const subject = `[Contact Batina Media] ${name}${
    projectType ? " – " + projectType : ""
  }`;

  const logoUrl = config.public?.appBaseUrl
    ? `${config.public.appBaseUrl}/images/logo-batina-media.png`
    : null;

  // Version texte brut (sûre, lisible partout)
  const text = [
    `Nouveau message via le formulaire de contact :`,
    "",
    `Nom : ${name}`,
    `E-mail : ${email}`,
    `Organisation / projet : ${org || "-"}`,
    `Type de projet : ${projectType || "-"}`,
    `Budget indicatif : ${budget || "-"}`,
    `Délais / échéances : ${timeline || "-"}`,
    `Locale : ${locale || "-"}`,
    "",
    "Message :",
    message,
  ].join("\n");

  // Version HTML avec logo si disponible
  const htmlParts = [];

  htmlParts.push(`
    <div style="font-family: system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif; font-size:14px; color:#0f172a; line-height:1.6;">
  `);

  if (logoUrl) {
    htmlParts.push(`
      <div style="margin-bottom:16px;">
        <img src="${logoUrl}" alt="Batina Media" style="height:32px;">
      </div>
    `);
  }

  htmlParts.push(`
    <p style="margin:0 0 12px 0;">Nouveau message via le formulaire de contact Batina Media :</p>

    <p style="margin:0 0 8px 0;"><strong>Nom :</strong> ${name}</p>
    <p style="margin:0 0 8px 0;"><strong>E-mail :</strong> ${email}</p>
    <p style="margin:0 0 8px 0;"><strong>Organisation / projet :</strong> ${
      org || "-"
    }</p>
    <p style="margin:0 0 8px 0;"><strong>Type de projet :</strong> ${
      projectType || "-"
    }</p>
    <p style="margin:0 0 8px 0;"><strong>Budget indicatif :</strong> ${
      budget || "-"
    }</p>
    <p style="margin:0 0 8px 0;"><strong>Délais / échéances :</strong> ${
      timeline || "-"
    }</p>
    <p style="margin:0 0 12px 0;"><strong>Locale :</strong> ${locale || "-"}</p>

    <p style="margin:0 0 6px 0;"><strong>Message :</strong></p>
    <div style="white-space:pre-wrap; border-radius:6px; padding:10px 12px; background:#f1f5f9;">
      ${message.replace(/</g, "&lt;").replace(/>/g, "&gt;")}
    </div>

    <p style="margin:16px 0 0 0; font-size:12px; color:#64748b;">
      — Notification automatique Batina Media
    </p>
  `);

  htmlParts.push(`</div>`);

  const html = htmlParts.join("");

  await transport.sendMail({
    from: config.mailFrom,
    to,
    replyTo: email,
    subject,
    text,
    html,
  });
}
